package com.dicoding.newsapp.ui.list

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.widget.SearchView
import androidx.annotation.StringRes
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.appcompat.widget.PopupMenu
import androidx.core.app.NotificationCompat
import com.dicoding.newsapp.R
import com.dicoding.newsapp.databinding.ActivityHomeBinding
import com.dicoding.newsapp.ui.ViewModelFactory
import com.dicoding.newsapp.ui.setting.SettingActivity
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator

class HomeActivity : AppCompatActivity() {
    private lateinit var binding: ActivityHomeBinding
    private var category: String = "science"

    private val requestPermissionLauncher =
        registerForActivityResult(
            ActivityResultContracts.RequestPermission()
        ){isGranted :Boolean->
            if (isGranted) {
                Toast.makeText(this, "Notifications permission granted", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Notifications permission rejected", Toast.LENGTH_SHORT).show()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHomeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        sendNotification("Hai Sobat TAM", "Dapatkan informasi berita terbaru sekarang!" )

        val factory: ViewModelFactory = ViewModelFactory.getInstance(this)
        val viewModel: NewsViewModel by viewModels {
            factory
        }
        viewModel.getThemeSettings().observe(this) { isDarkModeActive: Boolean ->
            if (isDarkModeActive) {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
            } else {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
            }
        }
        val sectionsPagerAdapter = SectionsPagerAdapter(this)
        binding.viewPager.adapter = sectionsPagerAdapter
        TabLayoutMediator(
            binding.tabs, binding.viewPager
        ) { tab: TabLayout.Tab, position: Int ->
            tab.text = resources.getString(TAB_TITLES[position])
        }.attach()

        supportActionBar?.elevation = 0f

        val refreshButton = binding.topAppBar.menu.findItem(R.id.refresh_button)
        val categoryButton = binding.topAppBar.menu.findItem(R.id.category_button)
        val settingButton = binding.topAppBar.menu.findItem(R.id.setting_button)
        val searchItem = binding.topAppBar.menu.findItem(R.id.search_bar)
        val searchView = searchItem.actionView as SearchView

        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener{
            override fun onQueryTextSubmit(query: String): Boolean {
                performSearch(query)
                return true
            }

            override fun onQueryTextChange(p0: String?): Boolean {
                return true
            }
        })

        refreshButton.setOnMenuItemClickListener {
            val fragment = supportFragmentManager.fragments.firstOrNull()
            Log.e("KATEGORI",category)
            if (fragment is NewsFragment) {
                fragment.refresh(category)
            }
            return@setOnMenuItemClickListener true
        }

        categoryButton.setOnMenuItemClickListener {
            showCategoryPopUpMenu(binding.anchor)

            true
        }

        settingButton.setOnMenuItemClickListener {
            val intent = Intent(this, SettingActivity::class.java)
            startActivity(intent)

            true
        }

        binding.tabs.addOnTabSelectedListener(object :TabLayout.OnTabSelectedListener{
            override fun onTabSelected(tab: TabLayout.Tab?) {
                tab.let {
                    when(it?.position){
                        0 -> {
                            searchItem.isVisible = true
                            refreshButton.isVisible = true
                            categoryButton.isVisible = true
                        }
                        1 -> {
                            searchItem.isVisible = false
                            refreshButton.isVisible = false
                            categoryButton.isVisible = false
                        }
                    }
                }
            }

            override fun onTabUnselected(tab: TabLayout.Tab?) {
                true
            }

            override fun onTabReselected(tab: TabLayout.Tab?) {
                true
            }

        })
    }

    private fun showCategoryPopUpMenu(anchorView : View) {
        val popUpMenu = PopupMenu(this, anchorView)
        popUpMenu.menuInflater.inflate(R.menu.category_menu,popUpMenu.menu)

        val menuItemBussiness = popUpMenu.menu.findItem(R.id.business)
        val menuItementertainment = popUpMenu.menu.findItem(R.id.entertainment)
        val general = popUpMenu.menu.findItem(R.id.general)
        val health = popUpMenu.menu.findItem(R.id.health)
        val science = popUpMenu.menu.findItem(R.id.science)
        val sports = popUpMenu.menu.findItem(R.id.sports)
        val technology = popUpMenu.menu.findItem(R.id.technology)

        if (category == "bussiness"){
            menuItemBussiness.title = "● bussiness"
        }else{
            menuItemBussiness.title = "bussiness"
        }

        if (category == "entertainment"){
            menuItementertainment.title = "● entertainment"
        }else{
            menuItementertainment.title = "entertainment"
        }
        if (category == "general"){
            general.title = "● general"
        }else{
            general.title = "general"
        }
        if (category == "health"){
            health.title = "● health"
        }else{
            health.title = "health"
        }
        if (category == "science"){
            science.title = "● science"
        }else{
            science.title = "science"
        }
        if (category == "sports"){
            sports.title = "● sports"
        }else{
            sports.title = "sports"
        }
        if (category == "technology"){
            technology.title = "● technology"
        }else{
            technology.title = "technology"
        }

        popUpMenu.setOnMenuItemClickListener { menuItem ->
            category = when (menuItem.itemId) {
                R.id.business -> "bussiness"
                R.id.entertainment -> "entertainment"
                R.id.general -> "general"
                R.id.health -> "health"
                R.id.science -> "science"
                R.id.sports -> "sports"
                R.id.technology -> "technology"
                else -> "bussiness"
            }
            val fragment = supportFragmentManager.fragments.firstOrNull()
            if (fragment is NewsFragment) {
                fragment.refresh(category)
            }

            true
        }

        popUpMenu.show()
    }

    private fun performSearch(query : String){
        val fragment = supportFragmentManager.fragments.firstOrNull()
        if (fragment is NewsFragment) {
            fragment.performSearch(query)
        }
    }

    private fun sendNotification(title:String, message:String){
        val notificationManager= getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val builder = NotificationCompat.Builder(this,CHANNEL_ID)
            .setContentTitle(title)
            .setSmallIcon(R.drawable.news_icon_notif)
            .setContentText(message)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setSubText("Update berita")

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
            val channel = NotificationChannel(
                CHANNEL_ID,
                CHANNEL_NAME,
                NotificationManager.IMPORTANCE_DEFAULT
            )
            builder.setChannelId(CHANNEL_ID)
            notificationManager.createNotificationChannel(channel)
        }
        val notification= builder.build()
        notificationManager.notify(NOTIFICATION_ID,notification)

    }
    companion object {
        @StringRes
        private val TAB_TITLES = intArrayOf(R.string.home, R.string.bookmark)

        private const val NOTIFICATION_ID = 1
        private const val CHANNEL_ID = "channel_01"
        private const val CHANNEL_NAME = "news channel"
    }
}