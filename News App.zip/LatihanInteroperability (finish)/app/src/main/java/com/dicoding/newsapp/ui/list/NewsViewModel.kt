package com.dicoding.newsapp.ui.list

import androidx.lifecycle.ViewModel
import com.dicoding.newsapp.data.NewsRepository

class NewsViewModel(private val newsRepository: NewsRepository) : ViewModel() {
    fun getHeadlineNews(category:String) = newsRepository.getHeadlineNews(category)

    fun getSearchNews(query : String?) = newsRepository.getSearchNews(query = query)

    fun getBookmarkedNews() = newsRepository.getBookmarkedNews()

    fun getThemeSettings() = newsRepository.getThemeSettings()
}