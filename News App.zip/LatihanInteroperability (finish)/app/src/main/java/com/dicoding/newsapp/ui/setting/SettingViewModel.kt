package com.dicoding.newsapp.ui.setting

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dicoding.newsapp.data.NewsRepository
import kotlinx.coroutines.launch

class SettingViewModel(private val newsRepository: NewsRepository):ViewModel() {
    fun saveThemeSetting(isDarkModeActive : Boolean) {
        viewModelScope.launch {
            newsRepository.saveThemeSetting(isDarkModeActive=isDarkModeActive)
        }
    }

    fun getThemeSettings() = newsRepository.getThemeSettings()
}