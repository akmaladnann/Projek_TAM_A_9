package com.dicoding.newsapp.ui.setting

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.CompoundButton
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.fragment.app.viewModels
import com.dicoding.newsapp.R
import com.dicoding.newsapp.ui.ViewModelFactory
import com.dicoding.newsapp.ui.list.NewsViewModel
import com.google.android.material.switchmaterial.SwitchMaterial

class SettingActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_setting)

        val factory: ViewModelFactory = ViewModelFactory.getInstance(this)
        val viewModel: SettingViewModel by viewModels {
            factory
        }
        val switchTheme = findViewById<SwitchMaterial>(R.id.switch_theme)

        val buttonOpenInstagram = findViewById<Button>(R.id.button_open_instagram)
        buttonOpenInstagram.setOnClickListener {
            openInstagram()
        }
        viewModel.getThemeSettings().observe(this) { isDarkModeActive: Boolean ->
            if (isDarkModeActive) {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
                switchTheme.isChecked = true
            } else {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
                switchTheme.isChecked = false
            }
        }

        switchTheme.setOnCheckedChangeListener { _: CompoundButton?, isChecked: Boolean ->
            viewModel.saveThemeSetting(isChecked)
        }
    }
    private fun openInstagram() {
        val instagramPackageName = "com.instagram.android"
        val intent = packageManager.getLaunchIntentForPackage(instagramPackageName)
        if (intent != null) {
            startActivity(intent)
        } else {
            val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.instagram.com"))
            startActivity(webIntent)
        }
    }
}